/**********************************************************************
 *  project2.txt template                                                   
 *  Project Part 2
 **********************************************************************/

PARTNER 1 (whose PennKey would come first in alphabetical order)
Partner 1 Name: Jalil Morris
Partner 1 NetID: jim33

PARTNER 2 (whose PennKey would come second in alphabetical order)
(If you chose to do this project without a partner, write NONE in each spot below.)
Partner 2 Name:
Partner 2 NetID:


/**********************************************************************
 *  Put your description of your project below.  If the description has
 *  not changed meaningfully, you can copy and paste your response.
 **********************************************************************/
   I will be creating the space invaders game (to the best of my ability)
using several objects to create the design and implementing practically
we have done in the past including recursion (mostly with design), arrays
(to control the amount of objects), animation (for the game), linked lists
(created my own class), other loops. My development will start with creating 
the ship designs. Then I will develop the gameplay feature such as moving and 
shooting. Then I design enemies and develop their controls. And lastly I will
put the finishing touches on everything (mostly the starting and ending 
animations and user interfaces).

/**********************************************************************
 *  Describe how to run your project. Ideally, it should be as simple
 *  as loading your project source files into Dr. Java. However, if 
 *  you use any external libraries, list them here.
 **********************************************************************/
   Make sure all the classes are present and in the same folder. Run Game.java
no arguments. No external libraries.



/**********************************************************************
 *  List whatever help (if any) that you received
 **********************************************************************/
None





/**********************************************************************
 *  Describe any serious problems you encountered.                    
 **********************************************************************/
None



/**********************************************************************
 *  List any other comments here. Feel free to provide any feedback   
 *  on how much you learned from doing the assignment, and whether    
 *  you enjoyed doing it.                                             
 **********************************************************************/



