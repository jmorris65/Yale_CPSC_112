/**********************************************************************
 *  project1.txt template                                                   
 *  Project Part 1
 **********************************************************************/

PARTNER 1 (whose NetID would come first in alphabetical order)
Partner 1 Name: Jalil Morris
Partner 1 NetID:  jim33

PARTNER 2 (whose NetID would come second in alphabetical order)
(If you chose to do this project without a partner, write NONE in each spot below.)
Partner 2 Name:
Partner 2 NetID:


/**********************************************************************
 *  Put your description of your project below.  It should be several
 *  paragraphs and cover all of the aspects in the section "Planning
 *  Your Project".
 **********************************************************************/
   I will be creating the space invaders game (to the best of my ability)
using several objects to create the design and implementing practically
we have done in the past including recursion (mostly with design), arrays
(to control the amount of objects), animation (for the game), linked lists
(created my own class), other loops. My development will start with creating 
the ship designs. Then I will develop the gameplay feature such as moving and 
shooting. Then I design enemies and develop their controls. And lastly I will
put the finishing touches on everything (mostly the starting and ending 
animations and user interfaces).

/**********************************************************************
 *  How precisely will your project use the LinkedList you implemented?
 **********************************************************************/
   I will use LinkedList to store user selections on Ship design. However
more importantly I will use Linked Lists to store and update bullet movement
on screen. Since it will be difficult (if not impossible) to use loops to 
show movement of the shots on screen. I will use LinkedList to store and
update their coordinates.
/**********************************************************************
 * How precisely will your project use recursion?
 **********************************************************************/
   Currently I only have recursion used in the design of ship. Using
recursion helped to create a small yet cool pattern on the ships.

/**********************************************************************
 *  List whatever help (if any) that you received
 **********************************************************************/

None




/**********************************************************************
 *  Describe any serious problems you encountered.                    
 **********************************************************************/

None


/**********************************************************************
 *  List any other comments here. Feel free to provide any feedback   
 *  on how much you learned from doing the assignment, and whether    
 *  you enjoyed doing it.                                             
 **********************************************************************/
Really fun